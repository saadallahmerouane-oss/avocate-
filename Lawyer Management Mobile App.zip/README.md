
  # Lawyer Management Mobile App

  This is a code bundle for Lawyer Management Mobile App. The original project is available at https://www.figma.com/design/cHOyIFU99NcwQ4UuuWNZqv/Lawyer-Management-Mobile-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  