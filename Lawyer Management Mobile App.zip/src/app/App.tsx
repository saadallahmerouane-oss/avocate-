import { useState } from "react";
import { Search, Bell, Menu } from "lucide-react";
import { CourtHearingCard } from "@/app/components/CourtHearingCard";
import { UrgentTaskItem } from "@/app/components/UrgentTaskItem";
import { NavigationBar } from "@/app/components/NavigationBar";
import { CaseDetails } from "@/app/components/CaseDetails";
import { CalendarScreen } from "@/app/components/CalendarScreen";

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "cases" | "calendar" | "fees">("home");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCaseDetails, setShowCaseDetails] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: "File motion for case #CR-2024-1847",
      dueDate: "Today, 3:00 PM",
      priority: "high" as const,
      completed: false,
    },
    {
      id: 2,
      title: "Review settlement agreement - Johnson v. Smith",
      dueDate: "Today, 5:00 PM",
      priority: "high" as const,
      completed: false,
    },
    {
      id: 3,
      title: "Prepare witness list for Martinez case",
      dueDate: "Tomorrow",
      priority: "medium" as const,
      completed: false,
    },
    {
      id: 4,
      title: "Client meeting prep - Estate Planning",
      dueDate: "Tomorrow, 10:00 AM",
      priority: "medium" as const,
      completed: false,
    },
  ]);

  const courtHearings = [
    {
      id: 1,
      caseNumber: "CR-2024-1847",
      clientName: "Sarah Martinez",
      courtRoom: "Courtroom 4B",
      time: "9:30 AM",
      type: "Criminal Defense - Hearing",
      status: "upcoming" as const,
    },
    {
      id: 2,
      caseNumber: "CV-2024-0932",
      clientName: "Johnson v. Smith",
      courtRoom: "Courtroom 2A",
      time: "2:00 PM",
      type: "Civil Litigation - Mediation",
      status: "upcoming" as const,
    },
    {
      id: 3,
      caseNumber: "CR-2024-1653",
      clientName: "Michael Chen",
      courtRoom: "Courtroom 7C",
      time: "4:15 PM",
      type: "Corporate Law - Contract Dispute",
      status: "upcoming" as const,
    },
  ];

  const toggleTask = (taskId: number) => {
    setTasks(
      tasks.map((task) =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    );
  };

  // Show Case Details screen if toggled
  if (showCaseDetails) {
    return <CaseDetails onBack={() => setShowCaseDetails(false)} />;
  }

  // Show Calendar screen if toggled
  if (showCalendar) {
    return <CalendarScreen onBack={() => setShowCalendar(false)} />;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile App Container */}
      <div className="max-w-[480px] mx-auto bg-slate-50 min-h-screen relative pb-24">
        {/* Header with Navy Blue background */}
        <header className="bg-gradient-to-br from-[#1e293b] to-[#0f172a] px-5 pt-12 pb-6 rounded-b-3xl shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <Menu className="w-6 h-6 text-white" />
            </button>
            <div className="text-center">
              <h1 className="text-white text-lg font-semibold tracking-wide">
                LegalHub
              </h1>
              <p className="text-slate-300 text-xs mt-0.5">Attorney Dashboard</p>
            </div>
            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors relative">
              <Bell className="w-6 h-6 text-white" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#d4af37] rounded-full"></span>
            </button>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search clients, cases..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 bg-white rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-[#d4af37] text-[15px] text-slate-800 placeholder:text-slate-400 shadow-sm"
            />
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-3 mt-5">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
              <p className="text-[#d4af37] text-2xl font-bold">3</p>
              <p className="text-slate-300 text-[11px] mt-0.5">Hearings</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
              <p className="text-[#d4af37] text-2xl font-bold">12</p>
              <p className="text-slate-300 text-[11px] mt-0.5">Active Cases</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
              <p className="text-[#d4af37] text-2xl font-bold">4</p>
              <p className="text-slate-300 text-[11px] mt-0.5">Urgent Tasks</p>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="px-5 py-6 space-y-6">
          {/* Today's Court Hearings Section */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-[17px] font-semibold text-[#0f172a]">
                  Today's Hearings
                </h2>
                <p className="text-sm text-slate-500">Monday, January 19, 2026</p>
              </div>
              <button className="text-[13px] text-[#d4af37] font-medium">
                View All
              </button>
            </div>
            <div className="space-y-3">
              {courtHearings.map((hearing) => (
                <div key={hearing.id} onClick={() => setShowCaseDetails(true)} className="cursor-pointer">
                  <CourtHearingCard {...hearing} />
                </div>
              ))}
            </div>
          </section>

          {/* Urgent Tasks Section */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[17px] font-semibold text-[#0f172a]">
                Urgent Tasks
              </h2>
              <button className="text-[13px] text-[#d4af37] font-medium">
                + Add Task
              </button>
            </div>
            <div className="space-y-2.5">
              {tasks.map((task) => (
                <UrgentTaskItem
                  key={task.id}
                  {...task}
                  onToggle={() => toggleTask(task.id)}
                />
              ))}
            </div>
          </section>

          {/* Recent Activity */}
          <section>
            <h2 className="text-[17px] font-semibold text-[#0f172a] mb-4">
              Recent Activity
            </h2>
            <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#d4af37] mt-2"></div>
                <div className="flex-1">
                  <p className="text-[15px] text-slate-800">
                    New document uploaded for case #CV-2024-0932
                  </p>
                  <p className="text-xs text-slate-500 mt-1">2 hours ago</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-slate-300 mt-2"></div>
                <div className="flex-1">
                  <p className="text-[15px] text-slate-800">
                    Payment received from Michael Chen
                  </p>
                  <p className="text-xs text-slate-500 mt-1">5 hours ago</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-slate-300 mt-2"></div>
                <div className="flex-1">
                  <p className="text-[15px] text-slate-800">
                    Court date rescheduled - Martinez case
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Yesterday</p>
                </div>
              </div>
            </div>
          </section>
        </main>

        {/* Navigation Bar */}
        <NavigationBar activeTab={activeTab} onTabChange={(tab) => {
          setActiveTab(tab);
          if (tab === "calendar") {
            setShowCalendar(true);
          }
        }} />
      </div>
    </div>
  );
}