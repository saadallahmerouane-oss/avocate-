import { useState } from "react";
import { ChevronLeft, ChevronRight, Plus, Filter, ArrowLeft } from "lucide-react";
import { SessionItem } from "@/app/components/SessionItem";

interface CalendarScreenProps {
  onBack: () => void;
}

export function CalendarScreen({ onBack }: CalendarScreenProps) {
  const [selectedDate, setSelectedDate] = useState(19); // January 19, 2026
  const [currentMonth, setCurrentMonth] = useState(0); // January (0-indexed)
  const [currentYear, setCurrentYear] = useState(2026);

  // Mock data for court dates (dates with scheduled sessions)
  const courtDates = [5, 10, 12, 15, 19, 22, 24, 26, 29];

  // Mock sessions data
  const sessionsData: { [key: number]: any[] } = {
    19: [
      {
        id: 1,
        time: "9:30 AM",
        caseNumber: "CR-2024-1847",
        clientName: "Sarah Martinez",
        courtRoom: "Courtroom 4B",
        sessionType: "Criminal Defense",
        status: "confirmed" as const,
      },
      {
        id: 2,
        time: "2:00 PM",
        caseNumber: "CV-2024-0932",
        clientName: "Johnson v. Smith",
        courtRoom: "Courtroom 2A",
        sessionType: "Civil Litigation",
        status: "confirmed" as const,
      },
      {
        id: 3,
        time: "4:15 PM",
        caseNumber: "CR-2024-1653",
        clientName: "Michael Chen",
        courtRoom: "Courtroom 7C",
        sessionType: "Corporate Law",
        status: "upcoming" as const,
      },
    ],
    22: [
      {
        id: 4,
        time: "10:00 AM",
        caseNumber: "CR-2024-1847",
        clientName: "Sarah Martinez",
        courtRoom: "Courtroom 4B",
        sessionType: "Pre-Trial Hearing",
        status: "upcoming" as const,
      },
      {
        id: 5,
        time: "3:30 PM",
        caseNumber: "CV-2024-1124",
        clientName: "Anderson Estate",
        courtRoom: "Courtroom 1A",
        sessionType: "Estate Planning",
        status: "upcoming" as const,
      },
    ],
    24: [
      {
        id: 6,
        time: "11:00 AM",
        caseNumber: "CR-2024-1901",
        clientName: "Robert Williams",
        courtRoom: "Courtroom 5B",
        sessionType: "Motion Hearing",
        status: "rescheduled" as const,
      },
    ],
  };

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const renderCalendar = () => {
    const days = [];
    const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

    // Day headers
    const headers = dayNames.map((day) => (
      <div key={day} className="text-center text-xs font-semibold text-slate-500 py-2">
        {day}
      </div>
    ));

    // Empty cells for days before month starts
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`empty-${i}`} className="aspect-square"></div>);
    }

    // Calendar days
    for (let day = 1; day <= daysInMonth; day++) {
      const hasCourtDate = courtDates.includes(day);
      const isSelected = day === selectedDate;
      const isToday = day === 19 && currentMonth === 0 && currentYear === 2026;

      days.push(
        <button
          key={day}
          onClick={() => setSelectedDate(day)}
          className={`aspect-square rounded-xl flex flex-col items-center justify-center relative transition-all ${
            isSelected
              ? "bg-[#d4af37] text-[#0f172a] font-bold shadow-md scale-105"
              : isToday
              ? "bg-[#1e293b] text-white font-semibold"
              : "hover:bg-slate-100 text-slate-700"
          }`}
        >
          <span className="text-sm">{day}</span>
          {hasCourtDate && !isSelected && (
            <div className="absolute bottom-1.5 flex gap-0.5">
              <div className={`w-1 h-1 rounded-full ${isToday ? "bg-[#d4af37]" : "bg-[#d4af37]"}`}></div>
            </div>
          )}
          {hasCourtDate && isSelected && (
            <div className="absolute bottom-1.5 flex gap-0.5">
              <div className="w-1 h-1 rounded-full bg-[#0f172a]"></div>
            </div>
          )}
        </button>
      );
    }

    return (
      <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200">
        <div className="grid grid-cols-7 gap-1">
          {headers}
          {days}
        </div>
      </div>
    );
  };

  const selectedSessions = sessionsData[selectedDate] || [];

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-[480px] mx-auto bg-slate-50 min-h-screen pb-24">
        {/* Header */}
        <header className="bg-gradient-to-br from-[#1e293b] to-[#0f172a] px-5 pt-12 pb-6 rounded-b-3xl shadow-lg">
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={onBack}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <div className="flex-1">
              <h1 className="text-white text-lg font-semibold">Court Calendar</h1>
              <p className="text-slate-300 text-xs mt-0.5">Schedule & Sessions</p>
            </div>
            <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <Filter className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* Month Navigator */}
          <div className="flex items-center justify-between bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <button
              onClick={handlePrevMonth}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-white" />
            </button>
            <h2 className="text-white font-semibold text-base">
              {monthNames[currentMonth]} {currentYear}
            </h2>
            <button
              onClick={handleNextMonth}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-white" />
            </button>
          </div>
        </header>

        {/* Main Content */}
        <main className="px-5 py-6 space-y-6">
          {/* Calendar */}
          <section>
            {renderCalendar()}
            
            {/* Legend */}
            <div className="flex items-center justify-center gap-6 mt-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded bg-[#1e293b]"></div>
                <span className="text-xs text-slate-600">Today</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded bg-[#d4af37]"></div>
                <span className="text-xs text-slate-600">Selected</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-[#d4af37]"></div>
                <span className="text-xs text-slate-600">Court Date</span>
              </div>
            </div>
          </section>

          {/* Scheduled Sessions */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-[17px] font-semibold text-[#0f172a]">
                  Scheduled Sessions
                </h3>
                <p className="text-sm text-slate-500">
                  {monthNames[currentMonth]} {selectedDate}, {currentYear}
                </p>
              </div>
              <button className="flex items-center gap-1.5 px-3 py-2 bg-[#d4af37] text-[#0f172a] rounded-lg font-medium text-sm shadow-sm hover:bg-[#c49d2f] transition-colors">
                <Plus className="w-4 h-4" />
                Add
              </button>
            </div>

            {selectedSessions.length > 0 ? (
              <div className="space-y-3">
                {selectedSessions.map((session) => (
                  <SessionItem key={session.id} {...session} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl p-8 border border-slate-200 shadow-sm text-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <svg
                    className="w-8 h-8 text-slate-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <p className="text-slate-600 font-medium mb-1">No sessions scheduled</p>
                <p className="text-sm text-slate-500">
                  You have no court sessions on this date
                </p>
              </div>
            )}
          </section>

          {/* Quick Stats */}
          <section>
            <h3 className="text-[17px] font-semibold text-[#0f172a] mb-4">
              This Month
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
                <p className="text-2xl font-bold text-[#d4af37] mb-1">9</p>
                <p className="text-sm text-slate-600">Total Sessions</p>
              </div>
              <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
                <p className="text-2xl font-bold text-[#d4af37] mb-1">6</p>
                <p className="text-sm text-slate-600">Upcoming</p>
              </div>
              <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
                <p className="text-2xl font-bold text-emerald-600 mb-1">2</p>
                <p className="text-sm text-slate-600">Confirmed</p>
              </div>
              <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
                <p className="text-2xl font-bold text-amber-600 mb-1">1</p>
                <p className="text-sm text-slate-600">Rescheduled</p>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
