import { Home, Briefcase, Calendar, DollarSign } from "lucide-react";

interface NavigationBarProps {
  activeTab: "home" | "cases" | "calendar" | "fees";
  onTabChange: (tab: "home" | "cases" | "calendar" | "fees") => void;
}

export function NavigationBar({ activeTab, onTabChange }: NavigationBarProps) {
  const navItems = [
    { id: "home" as const, icon: Home, label: "Home" },
    { id: "cases" as const, icon: Briefcase, label: "Cases" },
    { id: "calendar" as const, icon: Calendar, label: "Calendar" },
    { id: "fees" as const, icon: DollarSign, label: "Fees" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#1e293b] border-t border-[#334155] shadow-lg">
      <div className="flex items-center justify-around h-20 max-w-[480px] mx-auto px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className="flex flex-col items-center justify-center gap-1 flex-1 h-full transition-all"
            >
              <div
                className={`p-2 rounded-xl transition-all ${
                  isActive ? "bg-[#d4af37]" : "bg-transparent"
                }`}
              >
                <Icon
                  className={`w-6 h-6 ${
                    isActive ? "text-[#1e293b]" : "text-slate-300"
                  }`}
                />
              </div>
              <span
                className={`text-[11px] ${
                  isActive ? "text-[#d4af37] font-semibold" : "text-slate-400"
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
