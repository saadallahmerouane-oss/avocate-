import { FileText, Download, Eye, MoreVertical } from "lucide-react";

interface DocumentItemProps {
  name: string;
  uploadDate: string;
  fileSize: string;
  type?: string;
}

export function DocumentItem({ name, uploadDate, fileSize, type = "PDF" }: DocumentItemProps) {
  return (
    <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start gap-3">
        {/* PDF Icon */}
        <div className="w-12 h-12 rounded-lg bg-red-50 flex items-center justify-center flex-shrink-0">
          <FileText className="w-6 h-6 text-red-600" />
        </div>

        {/* Document Info */}
        <div className="flex-1 min-w-0">
          <h4 className="text-[15px] font-medium text-[#0f172a] truncate">
            {name}
          </h4>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs text-slate-500">{fileSize}</span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500">{uploadDate}</span>
          </div>
          <span className="inline-block mt-2 px-2 py-0.5 bg-slate-100 text-slate-600 text-[10px] font-medium rounded">
            {type}
          </span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          <button className="p-2 hover:bg-slate-50 rounded-lg transition-colors">
            <Eye className="w-4 h-4 text-slate-600" />
          </button>
          <button className="p-2 hover:bg-slate-50 rounded-lg transition-colors">
            <Download className="w-4 h-4 text-slate-600" />
          </button>
          <button className="p-2 hover:bg-slate-50 rounded-lg transition-colors">
            <MoreVertical className="w-4 h-4 text-slate-600" />
          </button>
        </div>
      </div>
    </div>
  );
}
