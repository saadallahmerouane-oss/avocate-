import { Calendar, MapPin, Clock } from "lucide-react";

interface HearingTimelineItemProps {
  date: string;
  time: string;
  courtRoom: string;
  hearingType: string;
  outcome?: string;
  isLast?: boolean;
}

export function HearingTimelineItem({
  date,
  time,
  courtRoom,
  hearingType,
  outcome,
  isLast = false,
}: HearingTimelineItemProps) {
  return (
    <div className="flex gap-4">
      {/* Timeline indicator */}
      <div className="flex flex-col items-center">
        <div className="w-3 h-3 rounded-full bg-[#d4af37] border-2 border-white shadow-md"></div>
        {!isLast && <div className="w-0.5 h-full bg-slate-200 mt-1"></div>}
      </div>

      {/* Content */}
      <div className="flex-1 pb-6">
        <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h4 className="text-[15px] font-semibold text-[#0f172a]">
                {hearingType}
              </h4>
              <div className="flex items-center gap-2 mt-1 text-sm text-slate-600">
                <Calendar className="w-4 h-4" />
                <span>{date}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1.5 text-sm text-slate-600">
                <Clock className="w-4 h-4" />
                <span>{time}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-600 mb-2">
            <MapPin className="w-4 h-4" />
            <span>{courtRoom}</span>
          </div>

          {outcome && (
            <div className="mt-3 pt-3 border-t border-slate-100">
              <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">
                Outcome
              </p>
              <p className="text-sm text-slate-700">{outcome}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
