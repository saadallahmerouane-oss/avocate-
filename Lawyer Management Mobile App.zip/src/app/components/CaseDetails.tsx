import { ArrowLeft, Plus, Upload, Phone, Mail, Building2 } from "lucide-react";
import { HearingTimelineItem } from "@/app/components/HearingTimelineItem";
import { DocumentItem } from "@/app/components/DocumentItem";

interface CaseDetailsProps {
  onBack: () => void;
}

export function CaseDetails({ onBack }: CaseDetailsProps) {
  const caseInfo = {
    caseNumber: "CR-2024-1847",
    clientName: "Sarah Martinez",
    courtName: "Algiers Court",
    status: "ongoing" as const,
    caseType: "Criminal Defense",
    filingDate: "March 15, 2024",
    nextHearing: "January 22, 2026",
    attorney: "John Davidson",
  };

  const hearingTimeline = [
    {
      id: 1,
      date: "Jan 10, 2026",
      time: "10:00 AM",
      courtRoom: "Courtroom 4B",
      hearingType: "Pre-Trial Conference",
      outcome: "Motion to suppress evidence granted. Next hearing scheduled.",
    },
    {
      id: 2,
      date: "Dec 5, 2025",
      time: "2:30 PM",
      courtRoom: "Courtroom 4B",
      hearingType: "Motion Hearing",
      outcome: "Defense filed motion to suppress evidence. Continued to next hearing.",
    },
    {
      id: 3,
      date: "Nov 18, 2025",
      time: "9:00 AM",
      courtRoom: "Courtroom 4B",
      hearingType: "Arraignment",
      outcome: "Defendant entered not guilty plea. Bail set at $50,000.",
    },
  ];

  const documents = [
    {
      id: 1,
      name: "Motion to Suppress Evidence.pdf",
      uploadDate: "Jan 5, 2026",
      fileSize: "2.4 MB",
    },
    {
      id: 2,
      name: "Client Statement - Martinez.pdf",
      uploadDate: "Dec 28, 2025",
      fileSize: "856 KB",
    },
    {
      id: 3,
      name: "Police Report - Case 1847.pdf",
      uploadDate: "Nov 20, 2025",
      fileSize: "1.2 MB",
    },
    {
      id: 4,
      name: "Witness List.pdf",
      uploadDate: "Nov 15, 2025",
      fileSize: "324 KB",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-[480px] mx-auto bg-slate-50 min-h-screen">
        {/* Header */}
        <header className="bg-gradient-to-br from-[#1e293b] to-[#0f172a] px-5 pt-12 pb-6 rounded-b-3xl shadow-lg">
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={onBack}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <div className="flex-1">
              <h1 className="text-white text-lg font-semibold">Case Details</h1>
              <p className="text-slate-300 text-xs mt-0.5">{caseInfo.caseNumber}</p>
            </div>
            <div className="flex gap-2">
              <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                <Phone className="w-5 h-5 text-white" />
              </button>
              <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                <Mail className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>

          {/* Case Summary Card */}
          <div className="bg-white rounded-xl p-5 shadow-md">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h2 className="text-[17px] font-semibold text-[#0f172a] mb-1">
                  {caseInfo.clientName}
                </h2>
                <p className="text-sm text-slate-600">{caseInfo.caseType}</p>
              </div>
              <span
                className={`px-3 py-1.5 rounded-full text-xs font-semibold ${
                  caseInfo.status === "ongoing"
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-slate-100 text-slate-600"
                }`}
              >
                {caseInfo.status === "ongoing" ? "Ongoing" : "Closed"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-slate-500 mb-1">Court Name</p>
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#d4af37]" />
                  <p className="text-sm font-medium text-slate-800">
                    {caseInfo.courtName}
                  </p>
                </div>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Filing Date</p>
                <p className="text-sm font-medium text-slate-800">
                  {caseInfo.filingDate}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Next Hearing</p>
                <p className="text-sm font-medium text-[#d4af37]">
                  {caseInfo.nextHearing}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-1">Lead Attorney</p>
                <p className="text-sm font-medium text-slate-800">
                  {caseInfo.attorney}
                </p>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="px-5 py-6 space-y-6 pb-8">
          {/* Hearing Timeline Section */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[17px] font-semibold text-[#0f172a]">
                Hearing Timeline
              </h3>
              <button className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-[#0f172a] rounded-lg font-medium text-sm shadow-sm hover:bg-[#c49d2f] transition-colors">
                <Plus className="w-4 h-4" />
                Add Hearing
              </button>
            </div>

            <div className="bg-slate-50 rounded-xl p-4">
              {hearingTimeline.map((hearing, index) => (
                <HearingTimelineItem
                  key={hearing.id}
                  {...hearing}
                  isLast={index === hearingTimeline.length - 1}
                />
              ))}
            </div>
          </section>

          {/* Documents Section */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[17px] font-semibold text-[#0f172a]">
                Documents
              </h3>
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 text-slate-700 rounded-lg font-medium text-sm shadow-sm hover:bg-slate-50 transition-colors">
                <Upload className="w-4 h-4" />
                Upload
              </button>
            </div>

            <div className="space-y-3">
              {documents.map((doc) => (
                <DocumentItem key={doc.id} {...doc} />
              ))}
            </div>
          </section>

          {/* Case Notes Section */}
          <section>
            <h3 className="text-[17px] font-semibold text-[#0f172a] mb-4">
              Case Notes
            </h3>
            <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
              <textarea
                placeholder="Add notes about this case..."
                rows={4}
                className="w-full text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none resize-none"
              />
              <div className="flex justify-end mt-3 pt-3 border-t border-slate-100">
                <button className="px-4 py-2 bg-[#1e293b] text-white rounded-lg font-medium text-sm hover:bg-[#0f172a] transition-colors">
                  Save Notes
                </button>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
