import { AlertCircle, CheckCircle2 } from "lucide-react";

interface UrgentTaskItemProps {
  title: string;
  dueDate: string;
  priority: "high" | "medium" | "low";
  completed?: boolean;
  onToggle?: () => void;
}

export function UrgentTaskItem({
  title,
  dueDate,
  priority,
  completed = false,
  onToggle,
}: UrgentTaskItemProps) {
  const priorityColors = {
    high: "text-red-600",
    medium: "text-amber-600",
    low: "text-slate-500",
  };

  return (
    <div
      className="flex items-start gap-3 p-3 rounded-lg bg-white border border-slate-200"
      onClick={onToggle}
    >
      <button
        className="mt-0.5 flex-shrink-0"
        onClick={(e) => {
          e.stopPropagation();
          onToggle?.();
        }}
      >
        {completed ? (
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
        ) : (
          <div className="w-5 h-5 rounded-full border-2 border-slate-300" />
        )}
      </button>
      <div className="flex-1 min-w-0">
        <p
          className={`text-[15px] ${
            completed ? "line-through text-slate-400" : "text-slate-800"
          }`}
        >
          {title}
        </p>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-xs text-slate-500">{dueDate}</span>
          {!completed && (
            <>
              <span className="text-slate-300">•</span>
              <span className={`text-xs font-medium ${priorityColors[priority]}`}>
                {priority.charAt(0).toUpperCase() + priority.slice(1)} Priority
              </span>
            </>
          )}
        </div>
      </div>
      {!completed && <AlertCircle className={`w-4 h-4 ${priorityColors[priority]}`} />}
    </div>
  );
}
