import { Clock, MapPin } from "lucide-react";

interface CourtHearingCardProps {
  caseNumber: string;
  clientName: string;
  courtRoom: string;
  time: string;
  type: string;
  status: "upcoming" | "in-progress" | "completed";
}

export function CourtHearingCard({
  caseNumber,
  clientName,
  courtRoom,
  time,
  type,
  status,
}: CourtHearingCardProps) {
  const statusColors = {
    upcoming: "bg-amber-50 text-amber-700",
    "in-progress": "bg-emerald-50 text-emerald-700",
    completed: "bg-slate-100 text-slate-600",
  };

  return (
    <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
      <div className="flex items-start justify-between mb-3">
        <div>
          <p className="text-xs text-slate-500 mb-1">{caseNumber}</p>
          <h3 className="text-[15px] font-semibold text-[#0f172a]">{clientName}</h3>
        </div>
        <span
          className={`px-2.5 py-1 rounded-full text-[10px] font-medium ${statusColors[status]}`}
        >
          {status === "in-progress" ? "In Progress" : status.charAt(0).toUpperCase() + status.slice(1)}
        </span>
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-slate-600">
          <Clock className="w-4 h-4" />
          <span className="text-sm">{time}</span>
        </div>
        <div className="flex items-center gap-2 text-slate-600">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">{courtRoom}</span>
        </div>
      </div>
      <div className="mt-3 pt-3 border-t border-slate-100">
        <p className="text-xs text-slate-500">{type}</p>
      </div>
    </div>
  );
}
