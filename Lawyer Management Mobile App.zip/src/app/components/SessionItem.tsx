import { Clock, MapPin, User } from "lucide-react";

interface SessionItemProps {
  time: string;
  caseNumber: string;
  clientName: string;
  courtRoom: string;
  sessionType: string;
  status: "upcoming" | "confirmed" | "rescheduled";
}

export function SessionItem({
  time,
  caseNumber,
  clientName,
  courtRoom,
  sessionType,
  status,
}: SessionItemProps) {
  const statusConfig = {
    upcoming: {
      bg: "bg-blue-50",
      border: "border-blue-200",
      text: "text-blue-700",
      dot: "bg-blue-500",
    },
    confirmed: {
      bg: "bg-emerald-50",
      border: "border-emerald-200",
      text: "text-emerald-700",
      dot: "bg-emerald-500",
    },
    rescheduled: {
      bg: "bg-amber-50",
      border: "border-amber-200",
      text: "text-amber-700",
      dot: "bg-amber-500",
    },
  };

  const config = statusConfig[status];

  return (
    <div className={`bg-white rounded-xl p-4 border ${config.border} shadow-sm`}>
      {/* Time Badge */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${config.dot}`}></div>
          <div className={`px-3 py-1 rounded-lg ${config.bg}`}>
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-600" />
              <span className="text-sm font-semibold text-slate-700">{time}</span>
            </div>
          </div>
        </div>
        <span className={`text-[10px] font-medium uppercase tracking-wide ${config.text}`}>
          {status}
        </span>
      </div>

      {/* Case Info */}
      <div className="space-y-2">
        <div>
          <p className="text-xs text-slate-500 mb-0.5">{caseNumber}</p>
          <h4 className="text-[15px] font-semibold text-[#0f172a]">{clientName}</h4>
        </div>

        <div className="flex items-center gap-4 text-sm text-slate-600">
          <div className="flex items-center gap-1.5">
            <MapPin className="w-4 h-4" />
            <span>{courtRoom}</span>
          </div>
          <div className="h-3 w-px bg-slate-300"></div>
          <span>{sessionType}</span>
        </div>
      </div>
    </div>
  );
}
